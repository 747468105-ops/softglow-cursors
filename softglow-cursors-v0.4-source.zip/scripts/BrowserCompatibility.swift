import Foundation

let project = URL(fileURLWithPath: #filePath).deletingLastPathComponent().deletingLastPathComponent()
let whiteGlow = CommandLine.arguments.contains("--white-glow")
let glass = CommandLine.arguments.contains("--glass") || whiteGlow
let root = whiteGlow ? project.appendingPathComponent("Whiteglow-E") : (glass ? project.appendingPathComponent("Glass-v04") : project)
// Mirror MaCursor's browser aliases explicitly so each registration is independent.
let aliases: [String: String] = [
    "com.apple.coregraphics.Arrow": "com.apple.cursor.0",
    "com.apple.coregraphics.IBeam": "com.apple.cursor.1",
    "com.apple.cursor.2": "com.apple.coregraphics.Alias",
    "com.apple.cursor.4": "com.apple.coregraphics.Wait",
    "com.apple.cursor.11": "com.apple.coregraphics.ClosedHand",
    "com.apple.cursor.12": "com.apple.coregraphics.OpenHand",
    "com.apple.cursor.13": "com.apple.coregraphics.PointingHand",
    "com.apple.cursor.17": "com.apple.coregraphics.ResizeLeft",
    "com.apple.cursor.18": "com.apple.coregraphics.ResizeRight",
    "com.apple.cursor.19": "com.apple.coregraphics.ResizeLeftRight",
    "com.apple.cursor.21": "com.apple.coregraphics.ResizeUp",
    "com.apple.cursor.22": "com.apple.coregraphics.ResizeDown",
    "com.apple.cursor.23": "com.apple.coregraphics.ResizeUpDown",
    "com.apple.cursor.27": "com.apple.coregraphics.WindowResizeEast",
    "com.apple.cursor.28": "com.apple.coregraphics.WindowResizeEastWest",
    "com.apple.cursor.29": "com.apple.coregraphics.WindowResizeNortheast",
    "com.apple.cursor.30": "com.apple.coregraphics.WindowResizeNortheastSouthwest",
    "com.apple.cursor.31": "com.apple.coregraphics.WindowResizeNorth",
    "com.apple.cursor.32": "com.apple.coregraphics.WindowResizeNorthSouth",
    "com.apple.cursor.33": "com.apple.coregraphics.WindowResizeNorthwest",
    "com.apple.cursor.34": "com.apple.coregraphics.WindowResizeNorthwestSoutheast",
    "com.apple.cursor.35": "com.apple.coregraphics.WindowResizeSoutheast",
    "com.apple.cursor.36": "com.apple.coregraphics.WindowResizeSouth",
    "com.apple.cursor.37": "com.apple.coregraphics.WindowResizeSouthwest",
    "com.apple.cursor.38": "com.apple.coregraphics.WindowResizeWest"
]

for palette in (whiteGlow ? ["blue"] : ["blue", "graphite"]) {
    let original = root.appendingPathComponent("themes/Softglow-\(palette)-trial01.cursor")
    var theme = try PropertyListSerialization.propertyList(from: Data(contentsOf: original), format: nil) as! [String: Any]
    var cursors = theme["Cursors"] as! [String: [String: Any]]
    let originalCount = cursors.count
    for (source, alias) in aliases {
        guard let entry = cursors[source] else { fatalError("Missing source: \(source)") }
        cursors[alias] = entry
    }
    theme["Cursors"] = cursors
    theme["Creator"] = "Chinwen / original Softglow study"
    theme["ThemeName"] = glass ? "Softglow \(palette == "blue" ? "Ice Blue" : "Smoke") - Crystal Glass" : "Softglow \(palette == "blue" ? "Blue" : "Graphite") - Browser Check"
    theme["Identifier"] = "Softglow.\(palette).\(glass ? "crystal04" : "browsercheck01")"
    theme["UUID"] = glass ? (palette == "blue" ? "17ECA6A0-0004-4EFA-9892-AAA000000001" : "17ECA6A0-0004-4EFA-9892-AAA000000002") : (palette == "blue" ? "B3349D70-7939-4F79-9053-71C61D260001" : "B3349D70-7939-4F79-9053-71C61D260002")
    theme["ThemeVersion"] = glass ? 0.4 : 0.31
    if whiteGlow {
        theme["ThemeName"] = "Softglow E - White Glow"
        theme["Identifier"] = "Softglow.blue.whiteglowE04"
        theme["UUID"] = "17ECA6A0-0004-4EFA-9892-EEE000000001"
    }
    let target = root.appendingPathComponent("themes/Softglow-\(palette)-browser-check.cursor")
    let data = try PropertyListSerialization.data(fromPropertyList: theme, format: .xml, options: 0)
    try data.write(to: target, options: .atomic)
    let check = try PropertyListSerialization.propertyList(from: Data(contentsOf: target), format: nil) as! [String: Any]
    let checked = check["Cursors"] as! [String: [String: Any]]
    for (source, alias) in aliases {
        precondition(NSDictionary(dictionary: checked[source]!).isEqual(to: checked[alias]!))
    }
    print("PASS \(palette): \(originalCount) original entries preserved; \(checked.count) explicit identifiers; matching alias artwork and hotspots")
}
