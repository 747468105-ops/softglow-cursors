import AppKit
import Foundation
import ImageIO

let whiteGlow = CommandLine.arguments.contains("--white-glow")
let palettes = whiteGlow ? ["blue"] : ["blue", "graphite"]
let root = URL(fileURLWithPath: #filePath).deletingLastPathComponent().deletingLastPathComponent().appendingPathComponent(whiteGlow ? "Whiteglow-E" : "Glass-v04")
let fm = FileManager.default
for path in ["source", "images/blue", "images/graphite", "previews", "themes"] {
    try fm.createDirectory(at: root.appendingPathComponent(path), withIntermediateDirectories: true)
}

// All geometry is original. The same contours serve both palettes.
let paths: [(String, String)] = [
    ("Arrow", "M 14 12 C 12 11 11 12 12 15 L 20 34 C 21 36 23 36 24 33 L 27 26 L 34 23 C 37 22 36 20 33 19 Z"),
    ("Text", "M 18 12 L 29 12 M 23.5 12 L 23.5 36 M 18 36 L 29 36"),
    ("Link", "M 18 24 L 18 13 C 18 9 23 9 23 13 L 23 22 L 25 19 C 27 17 30 19 29 22 C 33 19 36 22 34 25 C 38 24 39 27 37 31 L 33 37 C 31 40 22 40 20 37 L 12 28 C 10 25 13 22 16 25 L 18 27 Z"),
    ("Open", "M 15 27 L 12 14 C 11 10 15 8 17 12 L 21 23 L 20 9 C 20 5 25 5 25 9 L 26 23 L 28 11 C 29 7 33 9 32 13 L 30 25 L 34 18 C 36 14 40 17 38 21 L 33 32 C 31 37 29 40 24 40 C 20 40 17 38 15 35 L 8 28 C 5 25 8 21 11 24 Z"),
    ("Closed", "M 14 23 C 11 22 10 26 12 29 L 18 37 C 20 40 30 40 33 36 L 36 29 C 38 25 35 22 32 24 C 33 20 29 18 26 21 C 25 17 21 17 20 21 C 17 18 13 19 14 23 Z M 20 23 L 20 28 M 26 23 L 26 28 M 32 25 L 31 29"),
    ("Resize", "M 9 24 L 17 16 L 17 21 L 31 21 L 31 16 L 39 24 L 31 32 L 31 27 L 17 27 L 17 32 Z")
]

func bezier(_ text: String) -> NSBezierPath {
    let regex = try! NSRegularExpression(pattern: "[MLCZ]|-?[0-9]+(?:\\.[0-9]+)?")
    let range = NSRange(text.startIndex..., in: text)
    let tokens = regex.matches(in: text, range: range).map { String(text[Range($0.range, in: text)!]) }
    var i = 0
    let path = NSBezierPath()
    func point() -> NSPoint {
        let x = Double(tokens[i])!, y = Double(tokens[i+1])!; i += 2
        return NSPoint(x: x, y: 48-y)
    }
    while i < tokens.count {
        let command = tokens[i]; i += 1
        switch command {
        case "M": path.move(to: point())
        case "L": path.line(to: point())
        case "C": let a = point(), b = point(), end = point(); path.curve(to: end, controlPoint1: a, controlPoint2: b)
        case "Z": path.close()
        default: fatalError("Unsupported path command")
        }
    }
    path.lineJoinStyle = .round; path.lineCapStyle = .round
    return path
}

func artwork(_ shape: String, palette: String, angle: CGFloat = 0) -> NSImage {
    return NSImage(size: NSSize(width: 48, height: 48), flipped: false) { _ in
    let c = NSGraphicsContext.current!.cgContext
    c.translateBy(x: 24, y: 24); c.rotate(by: angle); c.translateBy(x: -24, y: -24)
    let p = bezier(shape)
    let blue = palette == "blue"
    c.saveGState()
    let shadow = NSShadow(); shadow.shadowBlurRadius = whiteGlow ? 3.5 : 2.2
    shadow.shadowColor = NSColor(srgbRed: blue ? 0.48 : 0.68, green: blue ? 0.73 : 0.73, blue: blue ? 1 : 0.80, alpha: 0.33)
    shadow.shadowOffset = .zero; shadow.set()
    NSColor.white.withAlphaComponent(whiteGlow ? 0.90 : 0.65).setStroke()
    p.lineWidth = shape == paths[1].1 ? 2.4 : (whiteGlow ? 2.1 : 1.55); p.stroke()
    c.restoreGState()
    if shape != paths[1].1 {
        c.saveGState(); p.addClip()
        let top = whiteGlow ? NSColor(srgbRed:0.79,green:0.90,blue:1,alpha:0.70) : NSColor(srgbRed: blue ? 0.74 : 0.68, green: blue ? 0.88 : 0.72, blue: blue ? 1 : 0.77, alpha: 0.66)
        let middle = whiteGlow ? NSColor(srgbRed:0.54,green:0.73,blue:0.96,alpha:0.46) : NSColor(srgbRed: blue ? 0.37 : 0.23, green: blue ? 0.60 : 0.27, blue: blue ? 0.89 : 0.32, alpha: blue ? 0.29 : 0.40)
        let bottom = whiteGlow ? NSColor(srgbRed:0.72,green:0.86,blue:1,alpha:0.62) : NSColor(srgbRed: blue ? 0.62 : 0.48, green: blue ? 0.80 : 0.54, blue: blue ? 1 : 0.60, alpha: 0.53)
        NSGradient(colorsAndLocations: (bottom,0), (middle,0.48), (top,1))!.draw(in: NSRect(x:0,y:0,width:48,height:48), angle:90)
        // A clipped curved reflection gives every state the same polished glass finish.
        let reflection = NSBezierPath()
        reflection.move(to:NSPoint(x:0,y:40)); reflection.line(to:NSPoint(x:48,y:40))
        reflection.line(to:NSPoint(x:48,y:30))
        reflection.curve(to:NSPoint(x:0,y:17), controlPoint1:NSPoint(x:20,y:40), controlPoint2:NSPoint(x:23,y:15))
        reflection.close()
        NSColor.white.withAlphaComponent(whiteGlow ? 0 : 0.16).setFill(); reflection.fill()
        c.restoreGState()
        NSColor(srgbRed:0.20,green:0.34,blue:0.49,alpha:blue ? 0.30 : 0.44).setStroke()
        p.lineWidth = 1.8; p.stroke()
        NSColor.white.withAlphaComponent(0.97).setStroke(); p.lineWidth = whiteGlow ? 1.3 : 0.85; p.stroke()
        c.saveGState(); c.translateBy(x:0.35,y:-0.5)
        NSColor(srgbRed:blue ? 0.56 : 0.72,green:blue ? 0.81 : 0.80,blue:1,alpha:0.64).setStroke()
        p.lineWidth = whiteGlow ? 0.2 : 0.4; p.stroke(); c.restoreGState()
    }
    if shape == paths[1].1 {
        NSShadow().set()
        NSColor(srgbRed: blue ? 0.30 : 0.28, green: blue ? 0.49 : 0.30, blue: blue ? 0.78 : 0.34, alpha: 0.80).setStroke()
        p.lineWidth = 1; p.stroke()
        c.saveGState(); c.translateBy(x:-0.35,y:0.15)
        NSColor.white.withAlphaComponent(0.90).setStroke(); p.lineWidth = 0.4; p.stroke(); c.restoreGState()
    }
    return true
    }
}

func png(_ image: NSImage, size: NSSize) -> Data {
    let rep = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: Int(size.width), pixelsHigh: Int(size.height), bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
    NSGraphicsContext.saveGraphicsState(); NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: rep)
    image.draw(in: NSRect(origin: .zero, size: size))
    NSGraphicsContext.restoreGraphicsState()
    return rep.representation(using: .png, properties: [:])!
}

for palette in palettes {
    for (name, path) in paths {
        let color = palette == "blue" ? "#a6c7ff" : "#ebf0f7"
        let fill = palette == "blue" ? "#5e96f5" : "#40454d"
        let inner = name == "Text" ? "<path d=\"\(path)\" fill=\"none\" stroke=\"\(fill)\" stroke-opacity=\".8\" stroke-width=\".85\" stroke-linecap=\"round\"/>" : ""
        let stops = palette == "blue" ? "<stop stop-color='#bddfff' stop-opacity='.66'/><stop offset='.52' stop-color='#5e99e3' stop-opacity='.29'/><stop offset='1' stop-color='#9eccff' stop-opacity='.53'/>" : "<stop stop-color='#adb8c4' stop-opacity='.66'/><stop offset='.52' stop-color='#3b4552' stop-opacity='.40'/><stop offset='1' stop-color='#7a8a99' stop-opacity='.53'/>"
        let svg = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"48\" height=\"48\" viewBox=\"0 0 48 48\"><defs><linearGradient id=\"glass\" x2=\"0\" y2=\"1\">\(stops)</linearGradient><clipPath id=\"clip\"><path d=\"\(path)\"/></clipPath><filter id=\"glow\" x=\"-50%\" y=\"-50%\" width=\"200%\" height=\"200%\"><feGaussianBlur stdDeviation=\"1\"/></filter></defs><path d=\"\(path)\" fill=\"none\" stroke=\"\(color)\" stroke-width=\"2\" opacity=\".33\" filter=\"url(#glow)\"/><path d=\"\(path)\" fill=\"\(name == "Text" ? "none" : "url(#glass)")\" stroke=\"#35577d\" stroke-opacity=\".35\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\(name == "Text" ? inner : "<path d='M0 8H48V18C20 8 23 33 0 31Z' fill='white' opacity='.16' clip-path='url(#clip)'/>")<path d=\"\(path)\" fill=\"none\" stroke=\"white\" stroke-opacity=\".94\" stroke-width=\".85\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>"
        let frostedSVG = "<svg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'><defs><linearGradient id='frost' x1='0' y1='0' x2='0' y2='1'><stop stop-color='#c9e5ff' stop-opacity='.70'/><stop offset='.52' stop-color='#8abaF5' stop-opacity='.46'/><stop offset='1' stop-color='#b8dbff' stop-opacity='.62'/></linearGradient><filter id='halo' x='-50%' y='-50%' width='200%' height='200%'><feGaussianBlur stdDeviation='1.5'/></filter></defs><path d='\(path)' fill='none' stroke='#b0d7ff' stroke-width='2.1' opacity='.6' filter='url(#halo)'/><path d='\(path)' fill='\(name == "Text" ? "none" : "url(#frost)")' stroke='#426b96' stroke-opacity='.3' stroke-width='1.8' stroke-linejoin='round' stroke-linecap='round'/><path d='\(path)' fill='none' stroke='white' stroke-opacity='.97' stroke-width='\(name == "Text" ? "0.7" : "1.3")' stroke-linejoin='round' stroke-linecap='round'/></svg>"
        try (whiteGlow ? frostedSVG : svg).write(to: root.appendingPathComponent("source/\(palette)-\(name).svg"), atomically: true, encoding: .utf8)
        for scale in [1,2,3] {
            try png(artwork(path,palette:palette), size:NSSize(width:48*scale,height:48*scale)).write(to:root.appendingPathComponent("images/\(palette)/\(name)@\(scale)x.png"))
        }
    }
    let strip = NSImage(size:NSSize(width:48,height:48*24))
    strip.lockFocus()
    for frame in 0..<24 {
        let angle = sin(CGFloat(frame)/24 * 2 * .pi) * 7 * .pi/180
        artwork(paths[0].1,palette:palette,angle:angle).draw(in:NSRect(x:0,y:frame*48,width:48,height:48))
    }
    strip.unlockFocus()
    try png(strip,size:NSSize(width:96,height:96*24)).write(to:root.appendingPathComponent("images/\(palette)/Wait-rocking-strip@2x.png"))
}

let sheetHeight: CGFloat = whiteGlow ? 435 : 720
let sheet = NSImage(size:NSSize(width:1200,height:sheetHeight))
sheet.lockFocus()
NSColor(srgbRed:0.10,green:0.11,blue:0.13,alpha:1).setFill(); NSRect(x:0,y:0,width:1200,height:sheetHeight).fill()
func label(_ text:String,_ x:CGFloat,_ y:CGFloat,_ size:CGFloat,_ color:NSColor) {
    (text as NSString).draw(at:NSPoint(x:x,y:y),withAttributes:[.font:NSFont.systemFont(ofSize:size,weight:.medium),.foregroundColor:color])
}
label(whiteGlow ? "SOFTGLOW / E WHITE GLOW" : "SOFTGLOW / CRYSTAL GLASS",32,sheetHeight-47,22,.white)
label(whiteGlow ? "Chinwen / soft frosted blue / luminous white edge" : "Chinwen / A Ice Blue + D Smoke Glass / polished white rim",32,sheetHeight-74,13,.lightGray)
for (r,palette) in palettes.enumerated() {
    let y:CGFloat = whiteGlow ? 65 : (r == 0 ? 350 : 65)
    label(palette.uppercased(),32,y+242,16,.white)
    for (i,item) in paths.enumerated() {
        let x = CGFloat(30+i*195)
        NSColor(srgbRed:0.88,green:0.92,blue:0.95,alpha:1).setFill(); NSRect(x:x,y:y+60,width:90,height:170).fill()
        NSColor(srgbRed:0.15,green:0.17,blue:0.20,alpha:1).setFill(); NSRect(x:x+90,y:y+60,width:90,height:170).fill()
        let icon = artwork(item.1,palette:palette)
        icon.draw(in:NSRect(x:x+5,y:y+100,width:80,height:80))
        icon.draw(in:NSRect(x:x+95,y:y+100,width:80,height:80))
        label(item.0,x+8,y+31,14,.white)
    }
}
label("WAIT: 24-frame strip / +/-7 degrees / loading only / no motion on ordinary Arrow",32,25,13,.lightGray)
sheet.unlockFocus()
try png(sheet,size:NSSize(width:1200,height:sheetHeight)).write(to:root.appendingPathComponent("previews/first-study.png"))
let animationURL = root.appendingPathComponent("previews/wait-rocking.gif")
let destination = CGImageDestinationCreateWithURL(animationURL as CFURL, "com.compuserve.gif" as CFString, 24, nil)!
CGImageDestinationSetProperties(destination, [kCGImagePropertyGIFDictionary:[kCGImagePropertyGIFLoopCount:0]] as CFDictionary)
for frame in 0..<24 {
    let sample = NSImage(size:NSSize(width:320,height:120))
    sample.lockFocus()
    NSColor(srgbRed:0.88,green:0.92,blue:0.95,alpha:1).setFill(); NSRect(x:0,y:0,width:160,height:120).fill()
    NSColor(srgbRed:0.15,green:0.17,blue:0.20,alpha:1).setFill(); NSRect(x:160,y:0,width:160,height:120).fill()
    let angle = sin(CGFloat(frame)/24 * 2 * .pi) * 7 * .pi/180
    artwork(paths[0].1,palette:"blue",angle:angle).draw(in:NSRect(x:40,y:20,width:80,height:80))
    artwork(paths[0].1,palette:"graphite",angle:angle).draw(in:NSRect(x:200,y:20,width:80,height:80))
    sample.unlockFocus()
    let rep = NSBitmapImageRep(data:png(sample,size:NSSize(width:320,height:120)))!
    CGImageDestinationAddImage(destination,rep.cgImage!,[kCGImagePropertyGIFDictionary:[kCGImagePropertyGIFDelayTime:0.08]] as CFDictionary)
}
guard CGImageDestinationFinalize(destination) else { fatalError("GIF export failed") }
for palette in palettes {
    var cursors: [String:Any] = [:]
    func entry(_ reps:[Data], x:Double, y:Double, frames:Int = 1) -> [String:Any] {
        ["FrameCount":frames,"FrameDuration":frames == 1 ? 1.0 : 0.08,"HotSpotX":x,"HotSpotY":y,"PointsWide":48.0,"PointsHigh":48.0,"Representations":reps]
    }
    let roles:[(String,[String],Double,Double)] = [
        ("Arrow",["com.apple.coregraphics.Arrow","com.apple.coregraphics.ArrowS"],12.5,12.5),
        ("Text",["com.apple.coregraphics.IBeam","com.apple.coregraphics.IBeamS","com.apple.coregraphics.IBeamXOR"],23.5,24),
        ("Link",["com.apple.cursor.13","com.apple.cursor.2"],20.5,11),
        ("Open",["com.apple.cursor.12"],24,24),
        ("Closed",["com.apple.cursor.11"],24,28),
        ("Resize",["com.apple.cursor.19","com.apple.cursor.28"],24,24)
    ]
    for (name, identifiers, x, y) in roles {
        let reps = try [1,2,3].map { try Data(contentsOf:root.appendingPathComponent("images/\(palette)/\(name)@\($0)x.png")) }
        for identifier in identifiers { cursors[identifier] = entry(reps,x:x,y:y) }
    }
    let resizeGroups: [(String,CGFloat,[Int])] = [
        ("Resize-EW",0,[17,18,19,27,28,38]),
        ("Resize-NS",.pi/2,[21,22,23,31,32,36]),
        ("Resize-NESW",.pi/4,[29,30,37]),
        ("Resize-NWSE",-.pi/4,[33,34,35])
    ]
    for (name,angle,identifiers) in resizeGroups {
        let reps = [1,2,3].map { png(artwork(paths[5].1,palette:palette,angle:angle),size:NSSize(width:48*$0,height:48*$0)) }
        for (index,data) in reps.enumerated() { try data.write(to:root.appendingPathComponent("images/\(palette)/\(name)@\(index+1)x.png")) }
        for identifier in identifiers { cursors["com.apple.cursor.\(identifier)"] = entry(reps,x:24,y:24) }
    }
    let wait = try Data(contentsOf:root.appendingPathComponent("images/\(palette)/Wait-rocking-strip@2x.png"))
    cursors["com.apple.coregraphics.Wait"] = entry([wait],x:24,y:24,frames:24)
    cursors["com.apple.cursor.4"] = entry([wait],x:24,y:24,frames:24)
    let title = palette == "blue" ? "Softglow Blue - Trial 01" : "Softglow Graphite - Trial 01"
    let theme:[String:Any] = ["ThemeName":title,"Identifier":"Softglow.\(palette).trial01","UUID":palette == "blue" ? "D7DBFC3B-5846-4895-9827-385652349C01" : "D7DBFC3B-5846-4895-9827-385652349C02","Creator":"Chinwen / original Softglow study","ThemeVersion":0.4,"HiDPI":true,"Cursors":cursors]
    let data = try PropertyListSerialization.data(fromPropertyList:theme,format:.xml,options:0)
    try data.write(to:root.appendingPathComponent("themes/Softglow-\(palette)-trial01.cursor"))
    print("Packaged \(title): \(cursors.count) identifiers; unlisted roles use system defaults.")
}
print("Generated 12 SVG sources, 36 PNGs, 2 wait strips and comparison sheet.")
