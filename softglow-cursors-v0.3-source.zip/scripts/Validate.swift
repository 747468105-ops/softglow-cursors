import AppKit
import Foundation
let root = URL(fileURLWithPath:#filePath).deletingLastPathComponent().deletingLastPathComponent()
for palette in ["blue","graphite"] {
    let file = root.appendingPathComponent("themes/Softglow-\(palette)-trial01.cursor")
    let theme = try PropertyListSerialization.propertyList(from:Data(contentsOf:file),format:nil) as! [String:Any]
    let cursors = theme["Cursors"] as! [String:[String:Any]]
    precondition(cursors.count == 29)
    for key in ["com.apple.coregraphics.Arrow","com.apple.cursor.12","com.apple.cursor.30","com.apple.cursor.34"] { precondition(cursors[key] != nil) }
    for (key,cursor) in cursors {
        let w = cursor["PointsWide"] as! Double, h = cursor["PointsHigh"] as! Double
        let x = cursor["HotSpotX"] as! Double, y = cursor["HotSpotY"] as! Double
        let frames = cursor["FrameCount"] as! Int
        precondition(x >= 0 && x < w && y >= 0 && y < h,"Hotspot bounds: \(key)")
        for data in cursor["Representations"] as! [Data] {
            guard let rep = NSBitmapImageRep(data:data) else { fatalError("Invalid image") }
            precondition(rep.hasAlpha)
            precondition(abs(Double(rep.pixelsHigh)-h*Double(frames)*Double(rep.pixelsWide)/w)<0.01,"Frame dimensions: \(key)")
        }
    }
    precondition((cursors["com.apple.cursor.30"]!["Representations"] as! [Data]) != (cursors["com.apple.cursor.34"]!["Representations"] as! [Data]))
    print("PASS \(palette): 29 entries, decoded images, alpha, hotspot bounds, strip dimensions, distinct diagonals")
}
print("Visual click accuracy and cross-app behavior still require manual testing.")
