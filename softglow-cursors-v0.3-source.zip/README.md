# Softglow Cursors

轻柔、半透明、带微光的 macOS 指针主题。**v0.3 设计预览版，尚非完整指针包。**

![双配色预览](previews/first-study.png)

## 安装与恢复

在 [MaCursor](https://github.com/writronic/MaCursor) 中使用「文件 → 导入主题」，选择 `themes/` 下的蓝色或烟灰色 `.cursor` 文件，再点击「应用」。回退时选择原主题或点击「恢复」。

如果切换窗口后主题被覆盖，将系统自定义指针颜色重设为默认，再重新应用。大小在系统设置 → 无障碍 → 显示 → 指针中调整。

等待动画只在软件请求等待/忙碌指针时出现，不表示网页或 AI 的真实进度。

![等待动画](previews/wait-rocking.gif)

## Direction

Two palettes share geometry and hotspots: translucent blue and smoky graphite. Color, opacity and bloom are tuned separately for light and dark surfaces.

## Current Deliverables

- Six original roles per palette: Arrow, Text, Link, Open, Closed, Resize.
- Editable SVG sources and transparent PNG exports at 1x, 2x, 3x.
- Experimental 24-frame wait sprite sheet: gentle +/-7 degree rocking. Normal pointers remain static.
- Light/dark comparison sheet in previews/first-study.png.
- Both diagonal resize axes; 29 underlying identifiers / 27 visible MaCursor entries, not 27 distinct original shapes.
- Unimplemented roles use system defaults. See [coverage](COVERAGE.md).

## Known Limitations

- Copy, alias, forbidden, help, move, precision and other roles are unfinished.
- Directional window edges share double-ended artwork for the same axis.
- Hotspots require broader manual precision testing; mathematically valid bounds are not proof of click accuracy.
- Pale blue on light backgrounds and glow at small sizes need more testing.
- Tested by the author on one Mac; no cross-device compatibility certification.
- Applications that draw their own cursors may ignore system themes.
- SVGs are editable shape drafts; AppKit renders the exported PNGs, so SVG filters are not pixel-identical to PNG shadows.

## Build

On macOS with Swift and AppKit:

    swift -module-cache-path /tmp/softglow-module-cache scripts/Preview.swift

## Before Release

- User approval of contours, size, transparency and bloom.
- Test hotspot accuracy and animation timing in real apps.
- Complete all remaining roles in COVERAGE.md.
- Verify rendering at native scale across displays and common apps.
- Collect feedback on hand proportions and visual size consistency.

No system settings or installed cursor themes are modified by the build script.

## Credit and License

Project direction: Jingwen. Created with AI assistance. This is not an official OpenAI product, and no extracted OpenAI image assets or earlier mixed-theme experiments are included.

Original artwork in `source/`, `images/`, `previews/` and `themes/`: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Attribute "Softglow Cursors by Jingwen and contributors" and indicate modifications.

Scripts: MIT, see [LICENSE-CODE](LICENSE-CODE). See also [ATTRIBUTION.md](ATTRIBUTION.md).
